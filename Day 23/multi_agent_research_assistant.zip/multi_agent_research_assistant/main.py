from agents import (
    coordinator_agent,
    create_client,
    research_agent,
    writer_agent,
)


def main():
    print("=" * 60)
    print("       MULTI-AGENT RESEARCH ASSISTANT")
    print("=" * 60)
    print()
    print("Enter your request:")

    user_request = input("> ").strip()

    if not user_request:
        print("\nError: Please enter a non-empty request.")
        return

    try:
        client = create_client()

        print("\n[1] Coordinator Agent")
        print("Understanding the user request...")
        research_task = coordinator_agent(client, user_request)

        print("\n[2] Research Agent")
        print("Researching the topic...")
        research_findings = research_agent(client, research_task)

        print("\n[3] Writer Agent")
        print("Preparing the final answer...")
        final_answer = writer_agent(
            client,
            user_request,
            research_findings,
        )

        print("\n" + "=" * 60)
        print("FINAL ANSWER")
        print("=" * 60)
        print(final_answer)

    except ValueError as error:
        print(f"\nConfiguration Error: {error}")
    except Exception as error:
        print(f"\nError: Something went wrong while contacting Gemini.")
        print(f"Details: {error}")


if __name__ == "__main__":
    main()
