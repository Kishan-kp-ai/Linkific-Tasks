# Multi-Agent Research Assistant

## 1. Project Objective

This project is a simple multi-agent research assistant built with Python and the Gemini API.

It accepts a user request and passes the information through three specialized agents:

User -> Coordinator -> Research -> Writer -> Final Answer

## 2. Architecture

```text
User
  |
  v
Coordinator Agent
  |
  | Research Task
  v
Research Agent
  |
  | Research Findings
  v
Writer Agent
  |
  v
Final Answer
```

The agents communicate through normal Python function calls. The output of each agent is passed as input to the next agent.

## 3. Agent Responsibilities

| Agent | Responsibility |
|---|---|
| Coordinator Agent | Understands and routes the user request |
| Research Agent | Generates relevant research information |
| Writer Agent | Creates the final response |

## 4. Communication Flow

1. The user enters a request.
2. The Coordinator receives the request and creates a clear research task.
3. The Research Agent receives that research task and produces research findings.
4. The Writer Agent receives the original request plus the research findings.
5. The Writer creates the final answer.

This is sequential agent communication, not three unrelated Gemini prompts.

## 5. Example Interaction

```text
User:
Explain the impact of AI on software testing.

Coordinator:
Creates a research task covering applications, benefits,
challenges, and impact of AI in software testing.

Research Agent:
Produces concise research findings about those topics.

Writer Agent:
Uses the original request and research findings to create
a clear final response.

User:
Receives the final answer.
```

## 6. Challenges / Implementation Considerations

These are general implementation considerations, not errors claimed to have occurred during testing:

- Gemini API configuration must be correct.
- The API key must be stored in the `.env` file.
- Gemini API errors need simple error handling.
- Each agent's output must be passed correctly to the next agent.
- The Writer must continue answering the original user request rather than only summarizing the research findings.
- The selected Gemini model can change over time, so `MODEL_NAME` is kept in one place in `agents.py`.

## Setup

```bash
pip install -r requirements.txt
```

Put your real Gemini API key in `.env`:

```text
GEMINI_API_KEY=YOUR_API_KEY_HERE
```

Replace `YOUR_API_KEY_HERE` with your actual key.

## Run

```bash
python main.py
```

Example input:

```text
Explain the impact of AI on software testing.
```
