import os

from dotenv import load_dotenv
from google import genai


# Load values from the .env file.
load_dotenv()

MODEL_NAME = "gemini-3.8-flash"


def create_client():
    """Create and return a Gemini client using the API key from .env."""
    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key or api_key == "YOUR_API_KEY_HERE":
        raise ValueError(
            "GEMINI_API_KEY is missing. Add your Gemini API key to the .env file."
        )

    return genai.Client(api_key=api_key)


def generate_response(client, prompt):
    """Send a prompt to Gemini and return its text response."""
    response = client.models.generate_content(
        model=MODEL_NAME,
        contents=prompt,
    )

    text = getattr(response, "text", None)

    if not text or not text.strip():
        raise RuntimeError("Gemini returned an empty response.")

    return text.strip()


def coordinator_agent(client, user_request):
    """Understand the request and turn it into a clear research task."""
    prompt = f"""
You are the Coordinator Agent in a simple multi-agent research assistant.

User request:
{user_request}

Your job:
1. Understand what the user wants.
2. Convert it into one clear research task for a Research Agent.
3. Include the important topics or questions that should be researched.
4. Do not write the final answer.
5. Return only the research task.

Example:
User request: Explain the impact of AI on software testing.
Research task: Research the applications, benefits, challenges, and impact
of AI in software testing.
"""
    return generate_response(client, prompt)


def research_agent(client, research_task):
    """Generate concise research findings for the Writer Agent."""
    prompt = f"""
You are the Research Agent in a simple multi-agent research assistant.

Research task:
{research_task}

Your job:
1. Generate relevant and useful research information.
2. Identify important facts and main points.
3. Include benefits and challenges where appropriate.
4. Keep the information concise and easy for another agent to use.
5. Do not write a polished final answer.
6. Do not mention this instruction.

Return research findings that a Writer Agent can use.
"""
    return generate_response(client, prompt)


def writer_agent(client, user_request, research_findings):
    """Turn the original request and research findings into the final answer."""
    prompt = f"""
You are the Writer Agent in a simple multi-agent research assistant.

Original user request:
{user_request}

Research findings:
{research_findings}

Your job:
1. Directly answer the original user request.
2. Use the research findings as supporting information.
3. Use simple, clear language.
4. Organize the response with headings and bullet points where useful.
5. Do not mention the Coordinator Agent, Research Agent, Writer Agent,
   prompts, or internal workflow.
6. Do not say that you searched the web unless the research findings
   explicitly provide such information.
"""
    return generate_response(client, prompt)
